CREATE PROCEDURE 
mean_and_sd(nums OUT numsarray)
IS
    my_sd NUMERIC := 0;
    my_mean NUMERIC := 0;
    nums numsarray := numsarray();
BEGIN
    my_sd := compute_sd_books();
    my_mean := compute_mean_books();
    nums := nums(my_mean, my_sd);
END;

/* Part D */
DECLARE
    nums numsarray := numsarray();
BEGIN
    nums := mean_and_sd();
    dbms_output.put_line('Mean: ' || nums(0));
    dbms_output.put_line('SD: ' || nums(1));
END;
/
