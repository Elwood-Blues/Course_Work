CREATE FUNCTION compute_mean_books
RETURN NUMBER IS
    b_id book_loans.book_id%type;
    card_no book_loans.card_no%type;
    my_sum NUMERIC := 0.0;
    CURSOR my_cursor IS
        SELECT COUNT(book_id), card_no
        FROM book_loans
        GROUP BY card_no;
BEGIN
    OPEN my_cursor;
    LOOP
        FETCH my_cursor INTO b_id, card_no;
        EXIT WHEN my_cursor%NOTFOUND;
        my_sum := my_sum + b_id;
    END LOOP;
    my_sum := my_sum / my_cursor%ROWCOUNT;
    CLOSE my_cursor;
    RETURN my_sum;
END;
/
