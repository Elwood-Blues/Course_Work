CREATE FUNCTION compute_sd_books
RETURN NUMBER IS
    my_mean NUMERIC:= 0.0;
    my_n INTEGER := 0;
    b_id book_loans.book_id%type;
    card_no book_loans.card_no%type;
    my_running_val NUMERIC := 0.0;
    my_sd NUMERIC := 0.0;
    CURSOR my_cursor IS
        SELECT COUNT(book_id), card_no
        FROM book_loans
        GROUP BY card_no;
BEGIN
    OPEN my_cursor;
    my_mean := compute_mean_books();
    LOOP
        FETCH my_cursor INTO b_id, card_no;
        EXIT WHEN my_cursor%NOTFOUND;
        my_n := my_n + 1;
        my_running_val := my_running_val + POWER(b_id - my_mean, 2);
    END LOOP;
    my_sd := SQRT(my_running_val / (my_n -1));
    CLOSE my_cursor;
    RETURN my_sd;
END;
/
